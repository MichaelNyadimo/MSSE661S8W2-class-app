var email = document.forms['form']['email']
var password = document.forms['form']['password']

var email_error = document.getElementById('email_error');
var pass_error = document.getElementById('pass_error');

email.addEventListener('testInput, email_Verify');
password.addEventListener('testInput, pass_Verify');

function validated(){
    if (email.value.length < 6){
        email.style.border = "1px solid red";
        email_error.style.display = "block";
        email.focus();
        return false;
    }
}
function email_Verify(){
if (email.value.length >= 8){
    email.style.border = "2px solid red"
    email_error.style.display = "block";
    email_error.style.display = "none";
    return true;
  }
}
function pass_Verify(){
    if (password.value.length >= 8){
        password.style.border = "2px solid red"
        pass_error.style.display = "none";
        return true;
      }
    }